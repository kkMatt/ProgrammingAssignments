<?php
/**
 * Created by PhpStorm.
 * User: KestutisIT
 * Date: 2014/11/27
 * Time: 3:16 AM
 */
define("DB_HOST", "localhost");
define("DB_PORT", "3306");
define("DB_NAME", "test");
define("DB_USER", "admin");
define("DB_PASSWORD", "");
// Future
define("DB_PREFIX", "nfqapp12_");
define("BASE_URL", "http://localhost/GitHub/ProgrammingAssignments/NFQ-Challenge");