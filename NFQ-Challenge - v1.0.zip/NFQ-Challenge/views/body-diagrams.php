<article>
    <header>
        <h1>DB diagram & UML actions diagram</h1>
        <p>Please check code browser if needed</p>
    </header>
    <section>
        <h2>Database diagram</h2>
        <p>MySQL DB used: There is DIA ar PJG files</p>
        <p><img src="<?php print Flight::get('BASE'); ?>/FILES/DB_MODEL.jpeg" alt="DB_MODEL" title="Database model"/></p>
    </section>
    <section>
        <h2>Domain model (Sketch)</h2>
        <p>draw.io + Google Drive used. NOT Magic Draw. Sketch only</p>
        <p><img src="<?php print Flight::get('BASE'); ?>/FILES/draw-io_NFQ-Domain-Model.jpg" alt="DOMAIN_MODEL" title="Domain model - sketch"/></p>
    </section>
</article>