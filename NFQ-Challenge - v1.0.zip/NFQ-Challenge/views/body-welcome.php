<article>
    <header>
        <h1>Users in the system</h1>
        <p>Bellow we list all our users in the system</p>
    </header>
    <section class="holder">
        <div class="users"><p>Tomas [X]</p></div>
    </section>
</article>

<aside>
    <h3>Groups in the system</h3>
    <section class="holder">
        <div class="groups"><p>Group A</p></div>
    </section>
</aside>